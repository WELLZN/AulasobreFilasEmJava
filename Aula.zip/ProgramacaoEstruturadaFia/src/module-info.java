/**
 * 
 */
/**
 * 
 */
module ProgramacaoEstruturadaFia {
	requires java.desktop;
}