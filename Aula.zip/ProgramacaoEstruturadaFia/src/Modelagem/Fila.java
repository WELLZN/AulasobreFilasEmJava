package Modelagem;

import javax.swing.JOptionPane;

public class Fila{

	int inicio;
	int fim;
	int tamanho;
	int quantidadedePessoas;
	int f[];
	
	public Fila() {
		inicio = fim = -1;
		tamanho = 4;
		f =new int [tamanho];
		quantidadedePessoas = 0;
	}
	
	public boolean estaVazia() {
		if(quantidadedePessoas==0) {
			return true;
		}else {
			return false;
		}}
		
	public boolean estaCheia() {
		
		if (quantidadedePessoas == tamanho -1) {
			return true;
		}else {
			return false;
		}
	}
	
	public void adicionar(int e) {
		if(!estaCheia()) {
			if (inicio == -1) {
				inicio = 0;
			}
			fim++;
			f[fim] = e;
		}	
	}
	
	public void mostrarFila() {
		String pessoas="";
		for (int i = inicio; i<=fim; i++) {
			pessoas +=f[i]+"\t";
		}
		JOptionPane.showMessageDialog(null , pessoas);
	}
	
	
	public void retirar() {
		if(!estaVazia()) {
			inicio++;
			quantidadedePessoas--;
		}
	}
	
}
