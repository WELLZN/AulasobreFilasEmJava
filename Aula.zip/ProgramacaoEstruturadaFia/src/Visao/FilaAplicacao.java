package Visao;

import Modelagem.Fila;

public class FilaAplicacao {

	public static void main(String[] args) {
		Fila filadePessoas = new Fila();
		filadePessoas.adicionar(2510);
		filadePessoas.adicionar(2511);
		filadePessoas.adicionar(2512);
		
		filadePessoas.mostrarFila();
		
	}

}
